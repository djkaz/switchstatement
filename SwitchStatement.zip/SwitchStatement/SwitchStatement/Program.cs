﻿using System;

namespace SwitchStatement
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(GetDay(44));
            Console.ReadLine();
        }

        static String GetDay(int dayNum) {

            string dayName;
         

            switch(dayNum)
            {
                case 0:
                    dayName = "Sunday";
                    break;

                case 1:
                    dayName = "Monday";
                    break;

                case 2:
                    dayName = "Tuesday";
                    break;

                case 3:
                    dayName = "Tuesday";
                    break;

                case 4:
                    dayName = "Wednesday";
                    break;

                case 5:
                    dayName = "Thursday";
                    break;

                case 6:
                    dayName = "Friday";
                    break;
                case 7:
                    dayName = "Saturday";
                    break;
                default:
                    dayName = "Invalid Day Number";
                    break;


            } 
            return dayName;

        }
    }
}
